/*
 * ClusteringCoefficientWrapper.h
 *
 *  Created on: Nov 12, 2018
 *
 */

#ifndef UTILS_CLUSTERINGCOEFFICIENTWRAPPER_H_
#define UTILS_CLUSTERINGCOEFFICIENTWRAPPER_H_

#include "../includes/ClusteringCoefficientCalculator.h"
#include "WrapperIncludes.h"
void BoostDefClusteringCoefficient();

float ClusteringCoefWrapper(dict converted_dict);



#endif /* UTILS_CLUSTERINGCOEFFICIENTWRAPPER_H_ */
