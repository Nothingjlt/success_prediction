// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#define _CRT_SECURE_NO_DEPRECATE


#include <stdio.h>
#define _ELPP_THREAD_SAFE
#define  ELPP_THREAD_SAFE
#include "easylogging++.h"

typedef unsigned long long int64;



